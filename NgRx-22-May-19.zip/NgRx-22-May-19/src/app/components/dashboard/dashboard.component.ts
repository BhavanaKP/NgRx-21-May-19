import * as Highcharts from 'highcharts';
import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

import { AppState, selectAuthState } from '../../store/app.states';
import { LogOut } from '../../store/actions/auth.actions';
import { Employees } from '../../models/employees.model';
import { Projects } from '../../models/projects.model';
import { Availability } from '../../models/employeeAvailability.model';

import { LoadEmployees, ShowProjectDetails, ShowAvailability } from '../../store/actions/employee.actions';
import { getAllEmployees, getEmployeeProjects, getEmployeeAvailability } from '../../store/selectors/employee.selector';

declare var require: any;
const Boost = require('highcharts/modules/boost');
const noData = require('highcharts/modules/no-data-to-display');
const More = require('highcharts/highcharts-more');

Boost(Highcharts);
noData(Highcharts);
More(Highcharts);
noData(Highcharts);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  
  
  public getState: Observable<any>;
  public isAuthenticated = false;
  public user: any = null;
  public errorMessage: string = null;
  public employees: Employees[] = [];
  public projects: Projects[] = [];
  public availability: Availability[] = [];

  public pieChartOptions: any = {
   // Build the chart
   chart: {
    plotBackgroundColor: null,
    plotBorderWidth: null,
    plotShadow: false,
    type: 'pie'
  },
  title: {
    text: 'Employee Avalibilty'
  },
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
  },
  plotOptions: {
    pie: {
      allowPointSelect: true,
      cursor: 'pointer',
      dataLabels: {
        enabled: true,
        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
         }
    }
  },
  series: [{
    name: 'Bo Lais',
    colorByPoint: true,
    data: [{
      name: 'January',
      y: 40.41,
      sliced: true,
      selected: true
    }, {
      name: 'February',
      y: 20.84
    }, {
      name: 'March',
      y: 20.85
    }, {
      name: 'April',
      y: 5.67
    }, {
      name: 'May',
      y: 5.18
    }]
  }]
 };




  constructor(
    private store: Store<AppState>
  ) {
    this.getState = this.store.select(selectAuthState);
  }

  ngOnInit() {

    this.getState.subscribe((state) => {
      this.isAuthenticated = state.isAuthenticated;
      this.user = state.user;
      this.errorMessage = state.errorMessage;
    });

    if (this.isAuthenticated) {
      const payload = {
        employees: this.employees,
      };

      this.store.dispatch(new LoadEmployees(payload));

      this.store.select(getAllEmployees).subscribe((employee: Employees[]) => {
        this.employees = employee;
        if (this.employees) {
          this.employees = employee;
        }
      });

     // highcharts = Highcharts;

      // tslint:disable-next-line:member-ordering
      debugger;

      console.log(this.pieChartOptions);
     //  Highcharts.chart('container', columnChartOptions);
}

  }

  public searchEmployee(employeeName) {
    console.log('In Search Emp');
    console.log(employeeName);
    let searchedEmployee: any[];
    const realEmployees = this.employees;

    searchedEmployee = this.employees.filter((employee) => {
      if (employee.name === employeeName) {
        return employee;
      }
    });

    if (searchedEmployee && searchedEmployee.length > 0) {
      this.employees = searchedEmployee;
    } else {
      this.employees = realEmployees;
    }

    console.log(searchedEmployee.length);
    console.log(this.employees);
  }

  public onClickShowDetails(employeeId) {
    const payload = {
      employeeId,
    };

    this.store.dispatch(new ShowProjectDetails(payload.employeeId));
    this.store.select(getEmployeeProjects).subscribe((projects: Projects[]) => {
      this.projects = projects;
    });

    this.store.dispatch(new ShowAvailability(payload.employeeId));
    this.store.select(getEmployeeAvailability).subscribe((availabilitys: Availability[]) => {
      this.availability = availabilitys;
      console.log('Availablity DAta' + this.availability);
    });
    
    Highcharts.chart('container', this.pieChartOptions);
  }

  logOut(): void {
    // tslint:disable-next-line:new-parens
    this.store.dispatch(new LogOut);
  }

}
