import { Action } from '@ngrx/store';


export enum ActionTypes {
  LOAD_EMPLOYEES = 'Get All Employees',
  LOAD_EMPLOYEES_SUCCESS = 'Get Employees Success',
  SHOW_PROJECT_DETAILS = 'Show Project Details',
  SHOW_PROJECT_DETAILS_SUCCESS = 'Show Project Details Success',
  SHOW_AVAILABILITY = 'Show Project Details',
  SHOW_AVAILABILITY_SUCCESS = 'Show Project Details Success',
}

export class LoadEmployees implements Action {
  readonly type = ActionTypes.LOAD_EMPLOYEES;
  constructor(public payload: any) {}
}

export class LoadEmployeesSuccess implements Action {
  readonly type = ActionTypes.LOAD_EMPLOYEES_SUCCESS;
  constructor(public payload: any) {}
}

export class ShowProjectDetails implements Action {
    readonly type = ActionTypes.SHOW_PROJECT_DETAILS;
    constructor(public payload: any) {}
}

export class ShowProjectDetailsSuccess implements Action {
    readonly type = ActionTypes.SHOW_PROJECT_DETAILS_SUCCESS;
    constructor(public payload: any) {}
}

export class ShowAvailability implements Action {
  readonly type = ActionTypes.SHOW_AVAILABILITY;
  constructor(public payload:any) {}
}

export class ShowAvailabilitySuccess implements Action {
  readonly type = ActionTypes.SHOW_AVAILABILITY_SUCCESS;
  constructor(public payload:any) {}
}

export type Employees =
  | LoadEmployees
  | LoadEmployeesSuccess
  | ShowProjectDetails
  | ShowProjectDetailsSuccess
  | ShowAvailability
  | ShowAvailabilitySuccess;
