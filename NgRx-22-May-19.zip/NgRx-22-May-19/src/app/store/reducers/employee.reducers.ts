import { ActionTypes, Employees } from '../actions/employee.actions';
import { State } from '../state';

// export interface State {
//   // is a user authenticated?
//   isAuthenticated: boolean;
//   // if authenticated, there should be a user object
//   user: User | null;
//   // error message
//   errorMessage: string | null;
//   // employees
//   employees:any[];
// }


export const initialState: State = {
  isAuthenticated: false,
  user: null,
  errorMessage: null,
  employees: [],
  projects: [],
  availabilitys: [],
};

export function reducer(state = initialState, action: Employees): State {
  switch (action.type) {
    case ActionTypes.LOAD_EMPLOYEES_SUCCESS: {
      return {
        ...state,
        employees: action.payload
      };
    }
    case ActionTypes.SHOW_PROJECT_DETAILS_SUCCESS: {
      return {
        ...state,
        projects: action.payload
      };
    }
    case ActionTypes.SHOW_AVAILABILITY_SUCCESS: {
      return {
        ...state,
        availabilitys: action.payload
      };
    }
    default:
      return state;
  }
}
