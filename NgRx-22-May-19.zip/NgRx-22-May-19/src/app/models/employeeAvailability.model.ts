export class Availability {
    employeeId?: string;
    month?: string;
    percentage?: string;
  }
