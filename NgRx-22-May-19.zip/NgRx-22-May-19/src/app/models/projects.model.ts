export class Projects {
    projectId?: string;
    employeeId?: string;
    projectName?: string;
    projectDescription?: string;
  }
