import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employees } from '../models/employees.model';
import { Projects } from '../models/projects.model';


@Injectable()
export class EmployeesService {
  private BASE_URL = 'http://localhost:1337';

  constructor(private http: HttpClient) {}
  getEmployees(): Observable<Employees> {
    const url = `${this.BASE_URL}/getEmployees`;
    return this.http.get(url);
  }

  getProjectDetails(employeeId: string): Observable<Projects> {
    const url = `${this.BASE_URL}/getProjectDetails/${employeeId}`;
    console.log(url);
    return this.http.get<Projects>(url);
  }
}
