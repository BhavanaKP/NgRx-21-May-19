import { User } from '../models/user';
import { Employees } from '../models/employees.model';
import { Projects } from '../models/projects.model';

export interface State {
    // is a user authenticated?
    isAuthenticated: boolean;
    // if authenticated, there should be a user object
    user: User | null;
    // error message
    errorMessage: string | null;
    // All Employees
    employees: Employees[];
    // All Projects
    projects: Projects[];
  }
