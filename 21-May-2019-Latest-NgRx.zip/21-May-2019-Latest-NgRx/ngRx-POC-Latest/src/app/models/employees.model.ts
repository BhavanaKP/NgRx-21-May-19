export class Employees {
    id?: string;
    name?: string;
    role?: string;
    doj?: string;
  }
