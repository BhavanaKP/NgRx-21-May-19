import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

// import { User } from '../../models/user';
import { AppState, selectAuthState } from '../../store/app.states';
import { LogIn } from '../../store/actions/auth.actions';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {
  // user: User = new User();
  getState: Observable<any>;
  errorMessage: string | null;
  loginForm: FormGroup;
  isSubmitted = false;
  constructor(
    private store: Store<AppState>,
    private formBuilder: FormBuilder
  ) {
    this.getState = this.store.select(selectAuthState);
  }

  // ngOnInit() {
  //   this.getState.subscribe((state) => {
  //     this.errorMessage = state.errorMessage;
  //   });
  // }
  ngOnInit() {
    this.getState.subscribe((state) => {
      this.errorMessage = state.errorMessage;
    });

    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
  get formControls() { return this.loginForm.controls; }

  onSubmit(): void {
    // const payload = {
    //   email: this.user.email,
    //   password: this.user.password
    // };
    // this.store.dispatch(new LogIn(payload));
    const payload = {
      email: this.loginForm.value.email,
      password: this.loginForm.value.password
    };
    console.log(payload);
    if (this.loginForm.value.email && this.loginForm.value.password) {
      this.store.dispatch(new LogIn(payload));
     } // else {
    //   alert('Please enter valid data');
    // }
  }

}
