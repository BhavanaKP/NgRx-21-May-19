import * as Highcharts from 'highcharts';
import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

import { AppState, selectAuthState } from '../../store/app.states';
import { LogOut } from '../../store/actions/auth.actions';
import { Employees } from '../../models/employees.model';
import { LoadEmployees, ShowEmployeeDetails } from '../../store/actions/employee.actions';
import { getAllEmployees, getEmployeeDetails } from '../../store/selectors/employee.selector';
declare var require: any;
const Boost = require('highcharts/modules/boost');
const noData = require('highcharts/modules/no-data-to-display');
const More = require('highcharts/highcharts-more');

Boost(Highcharts);
noData(Highcharts);
More(Highcharts);
noData(Highcharts);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  public getState: Observable<any>;
  public isAuthenticated: boolean = false;
  public user: any = null;
  public errorMessage: string = null;
  public employees: Employees[] = [];


  public columnChartOptions: any = {
    chart: {
      type: 'pie',
      height: 400,
      width: 500
    },
    title: {
      text: 'Employee Details Heading'
    },
    xAxis: {
      type: 'category',
      labels: {
        rotation: -45,
        style: {
          fontSize: '13px',
          fontFamily: 'Verdana, sans-serif'
        }
      }
    },
    yAxis: {
      min: 0,
      title: {
        text: 'Employee Details1'
      }
    },
    legend: {
      enabled: false
    },
    series: [{
      name: 'Jane',
      data: [1, 0, 4]
    }, {
      name: 'John',
      data: [5, 7, 3]
    }]
  };

  constructor(
    private store: Store<AppState>
  ) {
    this.getState = this.store.select(selectAuthState);
  }

  ngOnInit() {

    this.getState.subscribe((state) => {
      this.isAuthenticated = state.isAuthenticated;
      this.user = state.user;
      this.errorMessage = state.errorMessage;
    });

    if (this.isAuthenticated) {
      console.log('HeRe');

      const payload = {
        employees: this.employees,
      };

      this.store.dispatch(new LoadEmployees(payload));

      this.store.select(getAllEmployees).subscribe((employee: Employees[]) => {
        this.employees = employee;
        if (this.employees) {
          console.log(this.employees);
          this.employees = employee;
        }
      });

      console.log(this.columnChartOptions);
      Highcharts.chart('chartTwo', this.columnChartOptions);
    }

  }

  public searchEmployee(employeeName) {
    console.log('In Search Emp');
    console.log(employeeName);
    let searchedEmployee: any[];
    const realEmployees = this.employees;

    searchedEmployee = this.employees.filter((employee) => {
      if (employee.name === employeeName) {
        return employee;
      }
    });

    if (searchedEmployee && searchedEmployee.length > 0) {
      this.employees = searchedEmployee;
    } else {
      this.employees = realEmployees;
    }

    console.log(searchedEmployee.length);
    console.log(this.employees);
  }

  public onClickShowDetails(employeeId) {
    console.log("Button Clicked!")
    console.log(employeeId)

    const payload = {
      employeeId: employeeId,
    };

    this.store.dispatch(new ShowEmployeeDetails(payload));

    this.store.select(getEmployeeDetails).subscribe((employee: Employees[]) => {
      this.employees = employee;
      if (this.employees) {
        console.log('On Selector');
        console.log(payload);
        console.log(this.employees);
        this.employees = employee;
      }
    });

  }

  logOut(): void {
    // tslint:disable-next-line:new-parens
    this.store.dispatch(new LogOut);
  }

}
