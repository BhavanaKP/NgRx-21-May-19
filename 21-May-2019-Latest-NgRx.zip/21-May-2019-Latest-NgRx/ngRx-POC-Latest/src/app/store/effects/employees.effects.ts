import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { tap, map, switchMap } from 'rxjs/operators';

import {
    ActionTypes,
    LoadEmployees,
    LoadEmployeesSuccess,
    ShowEmployeeDetails,
    ShowEmployeeDetailsSuccess,
  } from '../actions/employee.actions';
import { Employees } from '../../models/employees.model';
import { EmployeesService } from '../../services/employee.service';

@Injectable()
export class EmployeeEffects {

  constructor(
    private actions: Actions,
    private router: Router,
    private employeesService: EmployeesService
  ) {}

  // effects go here
@Effect()
LoadEmployees: Observable<any> = this.actions.pipe(
  ofType(ActionTypes.LOAD_EMPLOYEES),
  map((action: LoadEmployees) => action.payload),
  switchMap((payload) => {
    return this.employeesService.getEmployees().pipe(
      map((employee) => {
      return new LoadEmployeesSuccess({employees: employee});
    }));
  })
);

@Effect({ dispatch: false })
LoadEmployeesSuccess: Observable<any> = this.actions.pipe(
  ofType(ActionTypes.LOAD_EMPLOYEES_SUCCESS),
  tap((employee) => {
    console.log(employee);
  })
);

@Effect()
ShowEmployeeDetails: Observable<any> = this.actions.pipe(
  ofType(ActionTypes.LOAD_EMPLOYEES),
  map((action: ShowEmployeeDetails) => action.payload),
  switchMap((payload) => {
    console.log('In Effect');
    console.log(payload);
    return this.employeesService.getEmployeeDetails(payload.employees).pipe(
      map((employee) => {
      return new ShowEmployeeDetailsSuccess({employees: employee});
    }));
  })
);

@Effect({ dispatch: false })
ShowEmployeeDetailsSuccess: Observable<any> = this.actions.pipe(
  ofType(ActionTypes.SHOW_EMPLOYEE_DETAILS_SUCCESS),
  tap((employee) => {
    console.log(employee);
  })
);

}


