import { createSelector } from '@ngrx/store';
import { AppState } from '../app.states';
import { Employees } from '../../models/employees.model';

export class EmployeesSelector {
    debugger;
    public static getAllEmployees(employees): Employees[] {
        return employees.employees;
    }

    public static getEmployeeDetails(employees): Employees[] {
        return employees.employees;
    }
}

export const getAllEmployees = createSelector(
    (state: AppState) => state.employeeState.employees,
    EmployeesSelector.getAllEmployees,
);

export const getEmployeeDetails = createSelector(
    (state: AppState) => state.employeeState.employees,
    EmployeesSelector.getEmployeeDetails,
);


