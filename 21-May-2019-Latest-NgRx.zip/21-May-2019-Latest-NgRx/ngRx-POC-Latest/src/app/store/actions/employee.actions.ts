import { Action } from '@ngrx/store';


export enum ActionTypes {
  LOAD_EMPLOYEES = 'Get All Employees',
  LOAD_EMPLOYEES_SUCCESS = 'Get Employees Success',
  SHOW_EMPLOYEE_DETAILS = 'Show Employee Details',
  SHOW_EMPLOYEE_DETAILS_SUCCESS = 'Show Employee Details Sucess'
}

export class LoadEmployees implements Action {
  readonly type = ActionTypes.LOAD_EMPLOYEES;
  constructor(public payload: any) {}
}

export class LoadEmployeesSuccess implements Action {
  readonly type = ActionTypes.LOAD_EMPLOYEES_SUCCESS;
  constructor(public payload: any) {}
}

export class ShowEmployeeDetails implements Action {
    readonly type = ActionTypes.SHOW_EMPLOYEE_DETAILS;
    constructor(public payload: any) {}
}

export class ShowEmployeeDetailsSuccess implements Action {
    readonly type = ActionTypes.SHOW_EMPLOYEE_DETAILS_SUCCESS;
    constructor(public payload: any) {}
}

export type Employees =
  | LoadEmployees
  | LoadEmployeesSuccess
  | ShowEmployeeDetails
  | ShowEmployeeDetailsSuccess;

  