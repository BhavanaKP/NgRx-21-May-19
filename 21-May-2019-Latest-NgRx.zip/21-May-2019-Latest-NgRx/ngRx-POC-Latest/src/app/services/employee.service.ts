import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employees } from '../models/employees.model';


@Injectable()
export class EmployeesService {
  private BASE_URL = 'http://localhost:1337';

  constructor(private http: HttpClient) {}
  getEmployees(): Observable<Employees> {
    const url = `${this.BASE_URL}/getEmployees`;
    return this.http.get(url);
  }

  getEmployeeDetails(employeeId:string): Observable<Employees> {
    const url = `${this.BASE_URL}/getEmployeeDetails/${employeeId}`;
    console.log(employeeId);
    console.log(url);
    return this.http.get<Employees>(url);
  }

//   getCustomer(id: number): Observable<Customer> {
//     const url = `${this.customersUrl}/${id}`;
//     return this.http.get<Customer>(url);
//   }
}
